#/bin/sh
#############
#
#FILE : deploy.sh
#
#Description :
#       deploy the virtual lab
#
#Creation :
#Date     : 19/08/2015
#update   : 22/08/2015
#

green() {
	echo "\033[32m$1\033[0m"
}

red() {
	echo "\033[33;31m$1\033[0m"
}

blue() {
	echo "\033[33;34m$1\033[0m"
}


a="virtual_lab_"
b=$(date +%F)
c=".db"
file=$a$b$c

blue "Prepare to backup database"

if cp database/lab.db database/$file
then green "Success"
else red "Failed"; exit
fi

blue "Prepare to set rights to the database"
if chmod 777 database/* && chmod 777 database/
then green "Success"
else red "Failed"; exit
fi

blue "Prepare to removing caches and give the correct rights to the cache/log folders"
if chmod 777 app/cache -R && chmod 777 app/logs -R && php app/console cache:clear -e=prod && php app/console cache:clear -e=dev && chmod 777 app/cache -R && chmod 777 app/logs -R

then green "Success"
else red "Impossible to remove the caches, please check if you have the correct right";exit
fi

blue "Prepare to concatenation js/css files in one"
if php app/console assetic:dump -e=prod
then green "Success"
else red "Failed";exit
fi

blue "Prepare to update entities and schema (if needed)"
if php app/console doctrine:schema:update --force && php app/console doctrine:generate:entities Kent
then green "Success"
else red "Failed";exit
fi
blue "You can now use the application";exit



