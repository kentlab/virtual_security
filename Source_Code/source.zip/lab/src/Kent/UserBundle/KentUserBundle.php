<?php

namespace Kent\UserBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class KentUserBundle extends Bundle
{
}
