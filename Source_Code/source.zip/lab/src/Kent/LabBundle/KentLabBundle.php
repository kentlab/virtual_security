<?php

namespace Kent\LabBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class KentLabBundle extends Bundle
{
}
