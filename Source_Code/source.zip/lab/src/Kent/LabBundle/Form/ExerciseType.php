<?php

namespace Kent\LabBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class ExerciseType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('name','text', array("attr" => array("class" => "form-control")))
            ->add('flag','text', array('required' => false,"attr" => array( "class" => "form-control")))
            ->add('description','textarea', array("attr" => array("class" => "form-control", "rows" => "3")))
            ->add('linked_content', 'text', array("attr" => array("class" => "form-control")))
            ->add('category', 'entity', array( 'class' => 'KentLabBundle:Category','property' => 'name', "attr" => array("class" => "form-control")))
        ;
    }
    
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Kent\LabBundle\Entity\Exercise'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'kent_labbundle_exercise';
    }
}
