<?php

namespace Kent\LabBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Security\Csrf\CsrfToken;

use Kent\LabBundle\Entity\Exercise;
use Kent\LabBundle\Form\ExerciseType;
use Kent\LabBundle\Form\FlagVerificationType;

class ExerciseController extends Controller
{
    public function createAction()
    {
    	$request = $this->get("request");
        $EM = $this->getDoctrine()->getManager();
       	$exercise = $request->get('id') ? $EM->getRepository("KentLabBundle:Exercise")->find($request->get('id')) : new Exercise();
        $form = $this->createForm(new ExerciseType(), $exercise);
        $csrf = $this->get('form.csrf_provider');
        if ($request->getMethod() == "POST") {
            $form->bind($request);
            if ($form->isValid()) {
                $EM->persist($exercise);
                $EM->flush();
                $status = $request->get('id') != 0 ? "updated" : "added";
                $this->addFlash('success','Exercise <strong>'.$exercise->getName().'</strong> '.$status.' with success!');                
                return $this->redirect($this->generateUrl('kent_lab_admin_exercise_create'));
            }
            else {
                $errors = $this->get('validator')->validate($exercise);
                foreach ($errors as $key => $value) {
                    $this->addFlash('error', ucfirst($value->getPropertyPath()). ": ".$value->getMessage());
                }
            }
        }
        $exercises = $EM->getRepository("KentLabBundle:Exercise")->findBy(array(), array("name" => "ASC"));
        $id = $exercise->getId() != 0 ? $exercise->getId() : null;
        return $this->render('KentLabBundle:ExerciseAdmin:create.html.twig', array("delete_token" => $csrf->generateCsrfToken("delete_exercise"), "form" => $form->createView(), "exercises" => $exercises, "id" => $id));
    }

    public function viewAction($category, $id)
    {
    	$request = $this->get("request");
        $EM = $this->getDoctrine()->getManager();
		preg_match("/^\d*/", $category, $category_id);
        $category = $EM->getRepository("KentLabBundle:Category")->find($category_id[0]);    	
        $exercises = $EM->getRepository("KentLabBundle:Exercise")->findBy(array("category" => $category->getId()), array("name" => "ASC"));
    	if ($id == 0)
            $exercise = count($exercises) > 0 ? $exercises[0] : null;
        else
            $exercise = $EM->getRepository("KentLabBundle:Exercise")->find($id);

        return $this->render('KentLabBundle:Exercise:index.html.twig', array("exercise" => $exercise, "exercises" => $exercises, "category" => $category));
    }

    public function deleteAction($id, $token) {
        $EM = $this->getDoctrine()->getManager();
        $request = $this->get("request");
        $exercise = $EM->getRepository("KentLabBundle:Exercise")->find($id);
        $flag_verification = $this->get('security.csrf.token_manager')->isTokenValid(new CsrfToken('delete_exercise', $token));
        if ($flag_verification && $exercise) {
            $EM->remove($exercise);
            $EM->flush();
            $this->addFlash('success','Exercise <strong>'.$exercise->getName().'</strong> has been successfully deleted!');                
        }
        else
            $this->addFlash('error', "An error occurred, please try again!");
        return $this->redirect($request->headers->get('referer'));
    }


    public function flagValidationAction($id) {
        $request = $this->get("request");
        $form = $this->createForm(new FlagVerificationType());
        $form->handleRequest($request);
        if ($request->getMethod() == "POST") {
            if ($form->isValid()) {
                $EM = $this->getDoctrine()->getManager();
                $exercise = $EM->getRepository("KentLabBundle:Exercise")->find($id);
		        $answer = $form->getData();
                if ($exercise->getFlag() == $answer['flag'])
                    $this->addFlash('success','Good answer!');                
                else
                    $this->addFlash('error', "Sorry, it is not that");
            }
            return $this->redirect($this->getRequest()->headers->get('referer'));
        }
        return $this->render('KentLabBundle:Exercise:flag.html.twig', array("id" => $id, "form" => $form->createView()));
    }
}
