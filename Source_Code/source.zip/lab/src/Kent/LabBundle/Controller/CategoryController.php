<?php

namespace Kent\LabBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Security\Csrf\CsrfToken;

use Kent\LabBundle\Form\CategoryType;
use Kent\LabBundle\Entity\Category;

class CategoryController extends Controller
{
    public function createAction()
    {
    	$request = $this->get("request");
        $EM = $this->getDoctrine()->getManager();
        $category = $request->get('id') ? $EM->getRepository("KentLabBundle:Category")->find($request->get('id')) : new Category();
        $form = $this->createForm(new CategoryType(), $category);
        $csrf = $this->get('form.csrf_provider');
        if ($request->getMethod() == "POST") {
            $form->bind($request);
            if ($form->isValid()) {
                $EM->persist($category);
                $EM->flush();
                $status = $request->get('id') != 0 ? "updated" : "added";
                $this->addFlash('success','Category <strong>'.$category->getName().'</strong> '.$status.' with success!');                
                return $this->redirect($this->generateUrl('kent_lab_admin_category_create'));
            }
            else {
                $errors = $this->get('validator')->validate( $category );
                foreach ($errors as $key => $value) {
                    $this->addFlash('error', ucfirst($value->getPropertyPath()). ": ".$value->getMessage());
                }
            }
        }
        $categories = $EM->getRepository("KentLabBundle:Category")->findAll();
        $id = $category->getId() != 0 ? $category->getId() : null;
        return $this->render('KentLabBundle:CategoryAdmin:create.html.twig', array("delete_token" => $csrf->generateCsrfToken("delete_category"), "form" => $form->createView(), "categories" => $categories, "id" => $id));
    }

    public function deleteAction($id, $token) {
        $EM = $this->getDoctrine()->getManager();
        $request = $this->get("request");

        $category = $EM->getRepository("KentLabBundle:Category")->find($id);
        $token_verification = $this->get('security.csrf.token_manager')->isTokenValid(new CsrfToken('delete_category', $token));
        if ($token_verification == $token && $category) {
            $exercises = $EM->getRepository("KentLabBundle:Exercise")->findBy(array("category" => $category));
            foreach ($exercises as $key => $value) {
                $EM->remove($value);
            }
            $EM->remove($category);
            $EM->flush();
            $this->addFlash('success','Category <strong>'.$category->getName().'</strong> and its exercises have been successfully deleted!');                
        }
        else
            $this->addFlash('error', "An error occurred, please try again!");
        return $this->redirect($request->headers->get('referer'));
    }    
}
