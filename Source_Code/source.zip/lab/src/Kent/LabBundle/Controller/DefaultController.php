<?php

namespace Kent\LabBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class DefaultController extends Controller
{
    public function indexAction()
    {
    	$EM = $this->getDoctrine()->getManager();
        return $this->render('KentLabBundle:Default:home.html.twig', array('categories' => $EM->getRepository("KentLabBundle:Category")->findBy(array(), array('name' => 'ASC'))));
    }

    public function sidebarCategoryAction() {
    	$EM = $this->getDoctrine()->getManager();
        return $this->render('KentLabBundle:Default:sidebar_category.html.twig', array('categories' => $EM->getRepository("KentLabBundle:Category")->findBy(array(), array('name' => 'ASC'))));
    }
}
